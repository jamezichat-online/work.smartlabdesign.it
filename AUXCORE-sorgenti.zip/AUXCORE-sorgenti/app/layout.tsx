import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AUXCORE | ASP Ragusa",
  description: "Monitoraggio e rendicontazione del servizio di ausiliariato. Prototipo con dati dimostrativi.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/auxcore-symbol.png",
    shortcut: "/auxcore-symbol.png",
    apple: "/auxcore-symbol.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="it">
      <body className="antialiased">{children}</body>
    </html>
  );
}

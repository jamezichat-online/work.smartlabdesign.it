import React from 'react';
import {createRoot} from 'react-dom/client';
import './app/globals.css';

const isDashboard=window.location.pathname.replace(/\/+$/,'').endsWith('/dashboard');
const page=isDashboard?import('./app/dashboard/page'):import('./app/page');
page.then(({default:Page})=>createRoot(document.getElementById('root')!).render(<React.StrictMode><Page/></React.StrictMode>));

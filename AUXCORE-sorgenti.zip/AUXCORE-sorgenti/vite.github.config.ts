import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const projectRoot=fileURLToPath(new URL('.',import.meta.url));

export default defineConfig({
  root:resolve(projectRoot,'github'),
  base:'/auxcore/',
  publicDir:resolve(projectRoot,'public'),
  resolve:{alias:{'@':projectRoot}},
  plugins:[react()],
  build:{
    outDir:resolve(projectRoot,'github-dist'),
    emptyOutDir:true,
    rollupOptions:{input:{home:resolve(projectRoot,'github/index.html'),dashboard:resolve(projectRoot,'github/dashboard/index.html')}}
  }
});

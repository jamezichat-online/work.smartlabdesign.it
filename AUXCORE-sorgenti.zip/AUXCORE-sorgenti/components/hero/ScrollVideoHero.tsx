'use client';
import {useEffect,useRef} from 'react';

export default function ScrollVideoHero({src,resetKey=0}:{src:string;resetKey?:number}){
  const section=useRef<HTMLElement>(null),video=useRef<HTMLVideoElement>(null);

  useEffect(()=>{
    const el=section.current,v=video.current;
    if(!el||!v||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
    let raf=0,target=0,current=0;
    const update=()=>{
      const r=el.getBoundingClientRect(),range=Math.max(1,el.offsetHeight-innerHeight);
      target=Math.max(0,Math.min(1,-r.top/range));
    };
    const seek=(progress:number)=>{
      if(!Number.isFinite(v.duration)||v.duration<=0)return;
      const time=progress*(v.duration-.04);
      if(Math.abs(v.currentTime-time)>.01&&!v.seeking)v.currentTime=time;
      v.style.setProperty('--scrub',String(progress));
    };
    const restore=()=>{update();current=target;v.pause();seek(current)};
    const frame=()=>{
      const delta=target-current;
      current=Math.abs(delta)<.0001?target:current+delta*.18;
      seek(current);
      raf=requestAnimationFrame(frame);
    };
    update();current=target;v.pause();v.load();
    addEventListener('scroll',update,{passive:true});
    addEventListener('resize',restore);
    addEventListener('focus',restore);
    addEventListener('pageshow',restore);
    document.addEventListener('visibilitychange',restore);
    v.addEventListener('loadedmetadata',restore);
    v.addEventListener('loadeddata',restore);
    raf=requestAnimationFrame(frame);
    return()=>{
      cancelAnimationFrame(raf);
      removeEventListener('scroll',update);
      removeEventListener('resize',restore);
      removeEventListener('focus',restore);
      removeEventListener('pageshow',restore);
      document.removeEventListener('visibilitychange',restore);
      v.removeEventListener('loadedmetadata',restore);
      v.removeEventListener('loadeddata',restore);
    };
  },[src,resetKey]);

  return <section ref={section} className="reference-hero"><div className="reference-hero-sticky"><div className="reference-hero-copy"><h1>Al centro del servizio.<span>Ogni giorno, ogni dato.</span></h1><p>Dashboard di monitoraggio e rendicontazione del servizio di ausiliariato</p></div><div className="reference-video-frame"><video ref={video} src={src} muted playsInline preload="auto" poster="./hero-poster.jpg" aria-label="Operatori del servizio di ausiliariato in ambiente sanitario"/></div><span className="scroll-cue">SCORRI PER ESPLORARE</span></div></section>;
}

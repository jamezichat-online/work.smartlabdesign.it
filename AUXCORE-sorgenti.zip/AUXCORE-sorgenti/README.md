# AUXCORE · ASP Ragusa

Prototipo interattivo della dashboard di ausiliariato, con home e hero video controllata dallo scroll.

## Esperienza
Home: `/`. Dashboard: `/dashboard`; sezioni e filtri nei parametri URL.
Dati dimostrativi: 48 ordini, 80 operatori, oltre 2.800 turni, 30 segnalazioni e 40 documenti su sei mesi.
Il provider aggrega gli stessi dati usati da dettaglio ordine, turni e grafici.
Ticket modificabili dai ruoli operativi, con modifiche limitate alla sessione.
Documenti: anteprime dimostrative e download di riepiloghi CSV.

## Architettura
React / TypeScript, Vinext compatibile Next.js, Tailwind, componenti Radix e Recharts. `services/data-provider` separa accesso e presentazione; `services/nso-adapter` definisce il contratto di normalizzazione NSO. `types` descrive le relazioni per gli adapter futuri.

Non sono presenti una connessione NSO, importatori reali, un backend di autenticazione applicativa o persistenza delle modifiche. I ruoli lato UI sono dimostrativi e non costituiscono un confine di sicurezza. Non inserire dati personali reali nella demo.

## Verifica
Build e controllo TypeScript; verificati somma turni/ordini e riferimenti agli operatori. Interfaccia desktop, selezione impresa, apertura ordine e cambio ruolo verificati in anteprima. WebMCP implementato con feature detection, ma il browser di verifica non lo supporta.

## Avvio
Utilizzare i comandi gestiti Sites per dipendenze, anteprima e build. Il progetto mantiene il lockfile pnpm.

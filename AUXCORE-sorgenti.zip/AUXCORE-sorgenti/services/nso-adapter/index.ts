import {Order} from '@/types';
import {dataProvider} from '@/services/data-provider';
export interface NSOAdapter {importOrders(rows:Order[]):Promise<Order[]>;getOrders():Promise<Order[]>;getOrder(id:string):Promise<Order|undefined>;normalizeOrder(row:Order):Order;mapOrderLines(order:Order):{id:string;order_id:string;quantity:number;unit_of_measure:string}[]}
export class MockNSOAdapter implements NSOAdapter {async importOrders(rows:Order[]){return rows.map(r=>this.normalizeOrder(r))}async getOrders(){return (await dataProvider.load()).orders}async getOrder(id:string){return (await this.getOrders()).find(o=>o.id===id)}normalizeOrder(row:Order){if(!row.id||row.ordered<0)throw Error('Ordine non valido');return {...row}}mapOrderLines(o:Order){return [{id:o.id+'-L1',order_id:o.id,quantity:o.ordered,unit_of_measure:'HUR'}]}}
// API, XML e middleware potranno implementare NSOAdapter. Nessuna connessione NSO attiva.

import {Dataset} from '@/types';
import {createMockData} from '@/data/mock';
export interface DataProvider {load():Promise<Dataset>}
export class MockDataProvider implements DataProvider {async load(){return createMockData()}}
export class ApiDataProvider implements DataProvider {constructor(private baseUrl:string){} async load():Promise<Dataset>{const r=await fetch(this.baseUrl+'/dataset');if(!r.ok)throw new Error('Dati non disponibili');return r.json()}}
export const dataProvider:DataProvider=new MockDataProvider();
